﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Archivosv02
{
    public interface ISerializable2016
    {
        bool serializar();
    }
}
